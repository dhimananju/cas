from . import main
from . import uploaddocument
from . import editmortgageloan
from . import applicationlist