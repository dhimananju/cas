{
  "name"           :  "Report Viewer",
  "summary"        :  "Preview reports and PDF without download/print option",
  "category"       :  "Uncategorized",
  "version"        :  "17.0.0.1",
  "sequence"       :  1,
  "author"         :  "Target Integration.",
  "website"        :  "http://www.targetintegration.com",
  "depends"        :  ['web'],
  "data"           : ["security/ir.model.access.csv"],
  'license':'LGPL-3',
}