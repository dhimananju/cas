# -*- coding: utf-8 -*-

from . import mortgage_product
from . import res_company
from . import res_partner
from . import application_checklist
from . import application
from . import checklist_applicable
from . import documents_applicable